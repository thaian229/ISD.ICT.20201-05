package common.exception;

public class UtilityException extends RuntimeException{
    public UtilityException(String message) { super((message)); }
}
