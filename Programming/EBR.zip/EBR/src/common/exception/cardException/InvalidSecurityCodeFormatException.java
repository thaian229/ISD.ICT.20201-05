package common.exception.cardException;

public class InvalidSecurityCodeFormatException extends FormException {
    public InvalidSecurityCodeFormatException() {
        super("INVALID SECURITY CODE");
    }
}
