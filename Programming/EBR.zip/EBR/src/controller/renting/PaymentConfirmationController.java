package controller.renting;

import controller.BaseController;

public class PaymentConfirmationController extends BaseController {

    public void createRentingSession() {

    }

}
