package common.exception.cardException;

public class NullExpDateException extends FormException {
    public NullExpDateException() {
        super("EXP DATE IS NOT FILLED");
    }
}
