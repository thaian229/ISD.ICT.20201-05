package common.exception.cardException;

public class FormException extends RuntimeException{
    public FormException(String message) { super(message); }
}
