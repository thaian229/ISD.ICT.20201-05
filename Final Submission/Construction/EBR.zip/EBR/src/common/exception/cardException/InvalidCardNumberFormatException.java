package common.exception.cardException;

public class InvalidCardNumberFormatException extends FormException {
    public InvalidCardNumberFormatException() {
        super("INVALID CARD NUMBER");
    }
}
