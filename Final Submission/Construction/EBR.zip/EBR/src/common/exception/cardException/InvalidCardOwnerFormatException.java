package common.exception.cardException;

public class InvalidCardOwnerFormatException extends FormException {
    public InvalidCardOwnerFormatException() {
        super("INVALID CARD OWNER");
    }
}
