package model.payment.paymentCard;

/**
 * parent class for all payment method
 *
 * @author Nguyen Thai An
 * <p>
 * creted at: 25/12/2020
 * <p>
 * project name: EBR
 * <p>
 * teacher's name: Dr. Nguyen Thi Thu Trang
 * <p>
 * class name: TT.CNTT ICT 02 - K62
 */
public class PaymentCard {

}
