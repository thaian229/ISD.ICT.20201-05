package common.exception.cardException;

public class InvalidExpDateFormatException extends FormException {
    public InvalidExpDateFormatException() {
        super("INVALID EXP DATE");
    }
}
