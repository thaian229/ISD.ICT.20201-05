package views.screen;

import javafx.fxml.Initializable;

import java.net.URL;
import java.util.ResourceBundle;

/**
 * blank screen init for later screens
 *
 * @author Nguyen Thai An
 * <p>
 * creted at: 04/12/2020
 * <p>
 * project name: EBR
 * <p>
 * teacher's name: Dr. Nguyen Thi Thu Trang
 * <p>
 * class name: TT.CNTT ICT 02 - K62
 */
public class BlankHandler implements Initializable {
    @Override
    public void initialize(URL location, ResourceBundle resources) {

    }
}
